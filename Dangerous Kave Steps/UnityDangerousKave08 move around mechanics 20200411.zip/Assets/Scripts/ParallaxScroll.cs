﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParallaxScroll : MonoBehaviour
{
    private GameObject _player;
    public float _horizontalSyncRatio = 0.5f;
    public float _verticalSyncRatio = 0.1f;
    private Vector3 _originalPos;

    // Start is called before the first frame update
    void Start()
    {
        _player = GameObject.FindGameObjectWithTag("Player");
        _originalPos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        if (_player)
        {
            Vector3 offset = _player.transform.position - _originalPos;
            offset.x *= _horizontalSyncRatio;
            offset.y *= _verticalSyncRatio;
            transform.position = _originalPos + offset;
        }
    }
}
