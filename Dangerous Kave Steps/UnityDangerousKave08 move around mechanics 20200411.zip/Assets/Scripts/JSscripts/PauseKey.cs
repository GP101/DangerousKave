﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PauseKey : MonoBehaviour
{
    public GameObject pauseMenu;
    public GameObject pauseMenuLoader;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            pauseMenu.SetActive(!pauseMenu.activeSelf);
            pauseMenuLoader.SetActive(!pauseMenuLoader.activeSelf);
            Time.timeScale = pauseMenuLoader.activeSelf ? 0f : 1f;
            Time.timeScale = pauseMenu.activeSelf ? 0f : 1f;
        }
    }
}
