﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SawController : BoxBehaviour
{
    override public void OnStart()
    {
        SetState(EState.MOVING);
    }

    override public void OnOverlapped(Collider2D hit, ColliderDistance2D colliderDistance)
    {
        if (hit.gameObject.IsMovingObject())
        {
            hit.transform.Translate(colliderDistance.pointA - colliderDistance.pointB);
        }
        else
        {
            transform.Translate(colliderDistance.pointA - colliderDistance.pointB);
        }
    }
}
