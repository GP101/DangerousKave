﻿using UnityEngine;
using System.Collections.Generic;
using KaveUtil;

[RequireComponent(typeof(BoxCollider2D))]
public class CharacterController2D : MonoBehaviour
{
    enum CornerId
    {
        Left,
        Right,
        Top,
        Bottom, // 3
        LeftBottom, // 4
        RightBottom, // 5
        MAX
    }

    enum InternalEventType
    {
        DestroyCharacter,
        CornerCollision,
        MAX
    }

    struct InternalEvent
    {
        public InternalEventType eventType;
        public GameObject go;
        public int iParam;
    }

    struct CornerData
    {
        public Vector2 cornerOffset;
        public bool isCornerColl;
        public Collider2D cornerCollider2D;
    }

    [SerializeField, Tooltip("Max speed, in units per second, that the character moves.")]
    float _speed = 2;
    [SerializeField, Tooltip("Acceleration while grounded.")]
    float _walkAcceleration = 8;
    [SerializeField, Tooltip("Acceleration while in the air.")]
    float _airAcceleration = 4;
    [SerializeField, Tooltip("Deceleration applied when character is grounded and not attempting to move.")]
    float _groundDeceleration = 8;
    [SerializeField, Tooltip("Max height the character will jump regardless of gravity")]
    float _jumpHeight = 1.1f;
    float _maxFallingVelocity = 20.0f;

    private BoxCollider2D _boxCollider;
    private Vector2 _velocity;
    public Vector2 Velocity
    {
        get { return _velocity; }
    }

    public delegate void OnJumpingCallback(bool isJumping);
    public event OnJumpingCallback OnJumping;
    public delegate void OnCollisionCallback(Collider2D coll2d
        , ColliderDistance2D collDist2d);
    public event OnCollisionCallback OnCollision;

    /// <summary>
    /// Set to true when the character intersects a collider beneath
    /// them in the previous frame.
    /// </summary>
    private bool _isGrounded = false;
    private Vector2 _groundVelocity = new Vector2(0, 0);
    private bool _isJumping = false;
    private bool _isFacingRight = true;
    private int _hitCount = 0;
    private CornerData[] _cornerData = new CornerData[6];
    private int _numBottomColl = 0;
    private Queue<InternalEvent> _internalEvents = new Queue<InternalEvent>();

    void Awake()
    {
        _boxCollider = GetComponent<BoxCollider2D>();
        _InitializeCornerData();
        _maxFallingVelocity = _speed * _walkAcceleration;
    }

    void Update()
    {
        // test
        if (Input.GetKeyUp(KeyCode.Q))
        {
            RuntimeGameDataManager.DoLevelClear();
        }

        // Use GetAxisRaw to ensure our input is either 0, 1 or -1.
        float moveInput = Input.GetAxisRaw("Horizontal");

        if ((moveInput > 0 && _isFacingRight == false) || (moveInput < 0 && _isFacingRight == true))
            Flip(moveInput);

        if (_isGrounded  )
        {
            _velocity.y = 0;

            if (Input.GetButtonDown("Jump") && _isJumping == false)
            {
                _velocity.x += _groundVelocity.x;
                // Calculate the velocity required to achieve the target jump height.
                _velocity.y = Mathf.Sqrt(2 * _jumpHeight * Mathf.Abs(Physics2D.gravity.y));
            }
        }

        float acceleration = _isGrounded ? _walkAcceleration : _airAcceleration;
        float deceleration = _isGrounded ? _groundDeceleration : 0;

        if (moveInput != 0)
        {
            _velocity.x = Mathf.MoveTowards(_velocity.x, _speed * moveInput, acceleration * Time.deltaTime);
        }
        else
        {
            _velocity.x = Mathf.MoveTowards(_velocity.x, 0, deceleration * Time.deltaTime);
        }

        _velocity.y += Physics2D.gravity.y * Time.deltaTime;
        if (_velocity.y < -_maxFallingVelocity)
            _velocity.y = -_maxFallingVelocity;
        _UpdatePointCollInfo();
        if (_cornerData[( int )CornerId.Top].isCornerColl && _velocity.y > 0)
        {
            //Collider2D coll2d = _cornerData[( int )CornerId.Top].cornerCollider2D;
            //if (coll2d.transform.CompareTag("Box"))
            //{
            //    BoxBehaviour boxBehavior = coll2d.gameObject.GetComponent<BoxBehaviour>();
            //    if (boxBehavior)
            //    {
            //        boxBehavior.DoExternalCollision(gameObject);
            //    }
            //}
            _velocity.y = -_velocity.y;
        }

        Vector2 v = _velocity;
        if (_isGrounded)
            v += _groundVelocity;
        transform.Translate(v * Time.deltaTime);

        bool isGrounded = false;
        bool isJumping = _numBottomColl <= 0;// true;
        bool bDestroyCharacter = false;

        // Retrieve all colliders we have intersected after velocity has been applied.
        Collider2D[] hits = Physics2D.OverlapBoxAll(transform.position, _boxCollider.size, 0);
        _hitCount = hits.Length;
                                                       
        foreach (Collider2D hit in hits)
        {
            // Ignore our own collider.
            if (hit.transform == transform)
                continue;

            isJumping = false;
            ColliderDistance2D colliderDistance = hit.Distance(_boxCollider);

            _OnCollision(hit, colliderDistance);

            // Ensure that we are still overlapping this collider.
            // The overlap may no longer exist due to another intersected collider
            // pushing us out of this one.
            if (colliderDistance.isOverlapped)
            {
                if (hit.transform.CompareTag("Saw"))
                {
                    bDestroyCharacter = true;
                }

                if (hit.gameObject.IsMovingObject())
                {
                    transform.Translate(colliderDistance.pointA - colliderDistance.pointB);
                    if (_CheckSqueezeDestroy())
                        bDestroyCharacter = true;
                }
                else
                {
                    transform.Translate(colliderDistance.pointA - colliderDistance.pointB);
                }

                // If we intersect an object beneath us, set grounded to true. 
                if (Vector2.Angle(colliderDistance.normal, Vector2.up) < 90 && _velocity.y <= 0)
                {
                    isGrounded = true;
                }
            }
        }

        _isGrounded = isGrounded && _numBottomColl >= 1;

        Vector2 groundPos = transform.position;
        groundPos.y -= 0.02f;
        if (LevelManager.IsOverlapWithWorld(groundPos, transform))
            _isGrounded = true;

        if (isJumping != _isJumping)
        {
            _isJumping = isJumping;
            OnJumping(isJumping);
        }

        if (bDestroyCharacter)
        {
            _AddInternalEvent(new InternalEvent() { eventType=InternalEventType.DestroyCharacter});
        }
        _ProcessInternalEvent();
    }

    void OnDrawGizmos()
    {
        Color oldColor = Gizmos.color;
        Gizmos.color = Color.magenta;
        //string text = string.Format("{0} {1} {2}", _hitCount, _isGrounded, _isJumping);
        string text = string.Format("{0} {1} {2} {3} {4} {5}"
            , _cornerData[0].isCornerColl ? 1 : 0
            , _cornerData[1].isCornerColl ? 1 : 0
            , _cornerData[2].isCornerColl ? 1 : 0
            , _cornerData[3].isCornerColl ? 1 : 0
            , _cornerData[4].isCornerColl ? 1 : 0
            , _cornerData[5].isCornerColl ? 1 : 0);

        Util.DrawTextInSceneView(transform.position, text, Color.white);
        Gizmos.color = oldColor; // restore original Gizmos color
    }

    private void OnGUI()
    {
        GUI.Label(new Rect(0, 0, 100, 64), RuntimeGameDataManager.gameData.coinCounter.ToString());
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("OnTriggerEnter2D", gameObject);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log("OnCollisionEnter2D", gameObject);
    }

    void _OnCollision(Collider2D coll2d, ColliderDistance2D collDist2d)
    {
        if (OnCollision != null)
            OnCollision(coll2d, collDist2d);
        if (coll2d.transform.CompareTag("Box"))
        {
            BoxBehaviour boxBehavior = coll2d.gameObject.GetComponent<BoxBehaviour>();
            if (boxBehavior)
            {
                boxBehavior.DoExternalCollision( gameObject );
            }
        }
    }

    void _UpdatePointCollInfo()
    {
        _numBottomColl = 0;
        for (int i = 0; i < (int)CornerId.MAX; ++i)
        {
            Vector2 pos = transform.position;
            _cornerData[i].isCornerColl 
                = LevelManager.IsOverlapWithWorld(pos + _cornerData[i].cornerOffset
                    , transform, ref _cornerData[i].cornerCollider2D);
            if (_cornerData[i].isCornerColl)
            {
                Collider2D coll2d = _cornerData[i].cornerCollider2D;
                if (_IsBottomCornerId(i))
                    _numBottomColl += 1;
                if (coll2d)
                {
                    InternalEvent ie = new InternalEvent()
                    {
                        eventType = InternalEventType.CornerCollision,
                        go = coll2d.gameObject,
                        iParam = i
                    };
                    _AddInternalEvent(ie);
                }
            }
        }//for
        //if (_isJumping)
        //{
        //    if (_cornerData[0].isCornerColl || _cornerData[1].isCornerColl)
        //        _velocity.x = 0;
        //}
    }

    bool _CheckSqueezeDestroy()
    {
        bool bDestroy = false;
        if (_cornerData[0].isCornerColl && _cornerData[1].isCornerColl)
            bDestroy = true;
        if (_cornerData[2].isCornerColl && _isGrounded)
            bDestroy = true;
        return bDestroy;
    }

    void _DestroyCharacter()
    {
        Destroy(gameObject);
        Vector3 pos = transform.position;
        pos.y += 0.5f;
        LevelManager.CreateEffect(LevelManager.EffectType.BigImpact, pos, transform.rotation);
        LevelManager.CreateEffect(LevelManager.EffectType.BigImpact, transform.position, transform.rotation);
    }

    void _InitializeCornerData()
    {
        Debug.Assert(_boxCollider != null);
        float leftCollOffset = _boxCollider.offset.x - _boxCollider.size.x / 2 - 0.1f;
        float rightCollOffset = _boxCollider.offset.x + _boxCollider.size.x / 2 + 0.1f;
        float topCollOffset = _boxCollider.offset.y + _boxCollider.size.y / 2 + 0.1f;
        float bottomCollOffset = _boxCollider.offset.y - _boxCollider.size.y / 2 - 0.1f;
        _cornerData[0].cornerOffset = new Vector2(leftCollOffset, _boxCollider.offset.y); // left
        _cornerData[1].cornerOffset = new Vector2(rightCollOffset, _boxCollider.offset.y); // right
        _cornerData[2].cornerOffset = new Vector2(_boxCollider.offset.x, topCollOffset); // top
        _cornerData[3].cornerOffset = new Vector2(_boxCollider.offset.x, bottomCollOffset); // bottom
        _cornerData[4].cornerOffset = new Vector2(leftCollOffset + 0.2f, bottomCollOffset); // left-bottom
        _cornerData[5].cornerOffset = new Vector2(rightCollOffset - 0.2f, bottomCollOffset); // right-bottom
    }

    void Flip(float moveInput)
    {
        Vector3 scale = transform.localScale;
        if ((scale.x > 0.0f && moveInput < 0) || (scale.x < 0.0f && moveInput > 0))
        {
            scale.x *= -1;
            transform.localScale = scale;
            _isFacingRight = (scale.x > 0);
        }
    }

    bool _IsBottomCornerId(int id)
    {
        return id >= 3 && id <= 5;
        //return id >= (int)CornerId.Bottom && id <= (int)CornerId.RightBottom;
    }

    bool _IsInternalEventExist(InternalEvent ievent)
    {
        foreach (InternalEvent e in _internalEvents)
        {
            if (e.eventType == ievent.eventType && e.go == ievent.go && e.iParam == ievent.iParam)
            {
                return true;
            }
        }
        return false;
    }

    bool _AddInternalEvent(InternalEvent ievent, bool bAllowDuplicate=false)
    {
        if (bAllowDuplicate == false)
        {
            if (_IsInternalEventExist(ievent))
                return false;
        }

        _internalEvents.Enqueue(ievent);
        return true;
    }

    void _ProcessInternalEvent()
    {
        _groundVelocity = Vector2.zero;
        foreach (InternalEvent e in _internalEvents)
        {
            if (e.eventType == InternalEventType.DestroyCharacter)
            {
                _DestroyCharacter();
            }
            else if (e.eventType == InternalEventType.CornerCollision)
            {
                if (_IsBottomCornerId(e.iParam))
                {
                    _groundVelocity = e.go.GetVelocity();
                }

                if (e.go.CompareTag("Box"))
                {
                    BoxBehaviour boxBehavior = e.go.GetComponent<BoxBehaviour>();
                    if (boxBehavior)
                    {
                        boxBehavior.DoExternalCollision(gameObject);
                    }
                }
                else if (e.go.CompareTag("Saw"))
                {
                    _DestroyCharacter();
                }
            }//if.. else if..
        }
        _internalEvents.Clear();
    }
}//public class CharacterController2D : MonoBehaviour
