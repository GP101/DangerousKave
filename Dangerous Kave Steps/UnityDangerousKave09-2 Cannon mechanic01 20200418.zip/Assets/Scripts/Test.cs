﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Test : MonoBehaviour
{
    TilemapCollider2D _tilemap2d;

    // Start is called before the first frame update
    void Start()
    {
        _tilemap2d = GetComponent<TilemapCollider2D>();
    }

    // Update is called once per frame
    void Update()
    {
        GameObject go = _tilemap2d.gameObject;
    }

    void OnDrawGizmos()
    {
    }
}
