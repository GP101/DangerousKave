﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using KaveUtil;

[RequireComponent(typeof(BoxCollider2D))]
public class BoxBehaviour : MonoBehaviour
{
    public enum EState
    {
        IDLE,
        PREMOVING,
        MOVING
    }

    public float _speed = 1;
    [Range(0, 360)]
    public float _velocityDegree;
    [Range(0, 360)]
    public float[] _velocityDegrees;
    private int _currentVelocityIndex = 0;

    private GameObject _player;

    [SerializeField]
    private BoxCollider2D _boxCollider;
    [SerializeField]
    private Transform _boxArrow;
    private SpriteRenderer _arrowSprite;

    private float _acceleration = 1;
    private Vector2 _curVelocity = new Vector2(0, 0);
    private Vector2 _maxVelocity = new Vector2(1, -1);
    private int _numCollision = 0;
    private bool _isGrounded = false;
    private bool _isInAir = false;

    private EState _movingState = EState.IDLE;
    private float _stateTimer = 0.0f;
    private CircularQueue<Vector2> _posQueue = new CircularQueue<Vector2>(10);
    private float _posQueueInsertTimer = 0.0f; // insert position for every 0.1 second.

    private void Awake()
    {
        _player = GameObject.FindGameObjectWithTag("Player");
        CharacterController2D cc2d = _player.GetComponent<CharacterController2D>();
        //cc2d.OnCollision += OnCollisionCallback;
    }

    void Start()
    {
        _boxCollider = GetComponent<BoxCollider2D>();
        Debug.Assert(_boxCollider != null);

        _boxArrow = transform.Find("Box Arrow");
        if (_boxArrow)
        {
            _arrowSprite = _boxArrow.gameObject.GetComponent<SpriteRenderer>();
        }

        OnStart();
        UpdateMaxVelocity();
    }

    void Update()
    {
        _stateTimer += Time.deltaTime;
        if (_movingState == EState.IDLE)
        {
            _Update_StateIDLE();

            SetArrowSpriteColor(Color.white);
            
        }
        else if (_movingState == EState.PREMOVING)
        {
            SetArrowSpriteColor(Color.black);
            if (_stateTimer >= 1.0f)
            {
                _movingState = EState.MOVING;
                _stateTimer = 0.0f;
            }
        }
        else if (_movingState == EState.MOVING)
        {
            _Update_StateMOVING();
            //c.g = Mathf.PingPong(_stateTimer, 0.5f);
            SetArrowSpriteColor(Color.green);
        }
        /*virtual*/OnUpdate(_movingState, _stateTimer);
    }

    void OnDrawGizmos()
    {
        // draw velocity
        //
        UpdateMaxVelocity();
        Color oldColor = Gizmos.color;
        Gizmos.color = Color.red;
        Gizmos.DrawRay(transform.position, _maxVelocity);

        // draw state
        //
        string text = string.Format("{0} {1} {2}", _numCollision, _movingState, _stateTimer);
        Util.DrawTextInSceneView(transform.position, text, Color.white);
        Gizmos.color = oldColor; // restore original Gizmos color
    }

    void _Update_StateIDLE()
    {
        bool isMovingState = false;

        // Retrieve all colliders we have intersected after velocity has been applied.
        RaycastHit2D[] hits = Physics2D.BoxCastAll(transform.position, _boxCollider.size, 0, new Vector2(0, 0));
        if (hits.Length >= 1)
        {
            foreach (RaycastHit2D hit in hits)
            {
                // Ignore our own collider.
                if (hit.transform == transform)
                    continue;

                if (hit.transform.gameObject.IsMovingObject())
                {
                    isMovingState = true;
                    break;
                }
            }//foreach
        }

        if (isMovingState)
        {
            //_movingState = EState.PREMOVING;
            _movingState = EState.MOVING; // test _20200328_jintaeks
            _stateTimer = 0.0f;
        }
    }

    void _StateMOVING_UpdateCollision()
    {
        /*virtual*/ OnPreCollision();

        _curVelocity = Vector2.MoveTowards(_curVelocity, _maxVelocity, _acceleration * Time.deltaTime);
        transform.Translate(_curVelocity * Time.deltaTime);

        _isGrounded = false;
        bool isInAir = true;

        // Retrieve all colliders we have intersected after velocity has been applied.
        Collider2D[] hits = Physics2D.OverlapBoxAll(transform.position, _boxCollider.size, 0);

        _numCollision = hits.Length;

        foreach (Collider2D hit in hits)
        {
            // Ignore our own collider.
            if (hit.transform == transform)
                continue;

            if( hit.gameObject.IsMovingObject())
            {
                _stateTimer = 0.0f; // initialize timer when there is a collision with 'Player' or 'Box'
            }

            isInAir = false;
            ColliderDistance2D colliderDistance = hit.Distance(_boxCollider);

            if (colliderDistance.isOverlapped)
            {
                /*virtual*/ OnOverlapped( hit, colliderDistance);

                // If we intersect an object beneath us, set grounded to true. 
                if (Vector2.Angle(colliderDistance.normal, Vector2.up) < 90 && _curVelocity.y < 0)
                {
                    _isGrounded = true;
                }
            }
        }

        if (isInAir != _isInAir)
        {
            _isInAir = isInAir;
        }

        /*virtual*/ OnPostCollision();
    }

    void _Update_StateMOVING()
    {
        // process collision response
        _StateMOVING_UpdateCollision();

        // check possible next state
        _posQueueInsertTimer += Time.deltaTime;
        if (_posQueueInsertTimer >= 0.1f)
        {
            Vector2 pos = transform.position;
            _posQueue.Insert(pos);
            _posQueueInsertTimer -= 0.1f;
        }
        if (_stateTimer >= 1.0f)
        {
            Vector2 vFront;
            Vector2 vRear;
            bool bFront = _posQueue.GetFront(out vFront);
            bool bRear = _posQueue.GetRear(out vRear);
            if (bFront && bRear)
            {
                float dist = Vector2.Distance(vFront, vRear);
                if (dist <= 0.2f)
                {
                    if (_velocityDegrees.Length >= 1)
                    {
                        _currentVelocityIndex += 1;
                        _currentVelocityIndex %= _velocityDegrees.Length;
                        //if (_currentVelocityIndex >= _velocityDegrees.Length)
                        //    _currentVelocityIndex = 0;
                        _velocityDegree = _velocityDegrees[_currentVelocityIndex];
                        _curVelocity = new Vector2(0, 0);
                        UpdateMaxVelocity();
                        _stateTimer = 0.0f;
                        _posQueue.ClearAll();
                    }
                    else
                    {
                        _movingState = EState.IDLE;
                        _posQueue.ClearAll();
                        _stateTimer = 0.0f;
                    }//if.. else..
                }
            }
        }
    }

    void UpdateMaxVelocity()
    {
        _maxVelocity = Util.Rotate(Vector2.right, _velocityDegree * Mathf.Deg2Rad) * _speed;
        Quaternion q = Quaternion.AngleAxis(_velocityDegree, Vector3.forward);
        if( _boxArrow )
            _boxArrow.transform.SetPositionAndRotation(_boxArrow.transform.position, q);
    }

    public void SetArrowSpriteColor(Color c)
    {
        if( _arrowSprite )
            _arrowSprite.color = c;
    }

    public void SetState(EState state)
    {
        _movingState = state;
        _stateTimer = 0.0f;
    }

    public void OnExternalCollision(GameObject gameObject)
    {
        if( gameObject.CompareTag("Player"))
        {
            if (_movingState == EState.IDLE)
            {
                _movingState = EState.MOVING; // test _20200328_jintaeks
                _stateTimer = 0.0f;
            }//if
        }
    }

    virtual public void OnUpdate(EState movingState, float stateTimer)
    {
    }

    virtual public void OnPreCollision()
    {
    }

    virtual public void OnOverlapped(Collider2D hit, ColliderDistance2D colliderDistance)
    {
    }

    virtual public void OnPostCollision()
    {
    }

    virtual public void OnStart()
    {
    }
}//class BoxController
