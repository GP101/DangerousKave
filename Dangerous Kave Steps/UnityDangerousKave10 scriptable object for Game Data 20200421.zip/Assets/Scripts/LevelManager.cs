﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class LevelManager : MonoBehaviour
{
    public enum EffectType
    {
        BigImpact,
        SmallImpact,
        ItemEffect,
    }
    static private TilemapCollider2D _tilemap2d;
    [SerializeField]
    static private GameObject _bigImpact;
    [SerializeField]
    static private GameObject _smallImpact;
    [SerializeField]
    static private GameObject _itemEffect;
    static private GameObject _player;
    static Collider2D _hitDummy;

    void Awake()
    {
        Transform tilemap = transform.Find("Grid/Tilemap");
        _tilemap2d = tilemap.gameObject.GetComponent<TilemapCollider2D>();
        _bigImpact = Resources.Load("BigImpact") as GameObject;
        _smallImpact = Resources.Load("SmallImpact") as GameObject;
        _itemEffect = Resources.Load("ItemEffect") as GameObject;
        _player = GameObject.FindGameObjectWithTag("Player");
    }

    public static bool IsOverlapWithTilemap(Vector2 p)
    {
        if( _tilemap2d != null )
            return _tilemap2d.OverlapPoint(p);

        return false;
    }

    public static bool IsOverlapWithWorld(Vector2 p, Transform owner, ref Collider2D hitOut )
    {
        bool isOverlap = false;
        if (_tilemap2d != null)
            isOverlap = _tilemap2d.OverlapPoint(p);
        if (isOverlap)
            return true;

        Collider2D[] hits = Physics2D.OverlapPointAll(p);
        foreach (Collider2D hit in hits)
        {
            if (hit.transform == owner)
                continue;
            if (hit.CompareTag("Coin"))
                continue;
            isOverlap = true;
            hitOut = hit;// set [ref] parameter
            break;
        }
        return isOverlap;
    }

    public static bool IsOverlapWithWorld(Vector2 p, Transform owner)
    {
        return IsOverlapWithWorld(p, owner, ref _hitDummy);
    }

    public static void CreateEffect(EffectType type, Vector3 position, Quaternion rotation)
    {
        switch(type)
        {
            case EffectType.BigImpact:
                Instantiate(_bigImpact, position, rotation);
                break;
            case EffectType.SmallImpact:
                Instantiate(_smallImpact, position, rotation);
                break;
            case EffectType.ItemEffect:
                Instantiate(_itemEffect, position, rotation);
                break;
        }
    }
}//public class LevelManager : MonoBehaviour
