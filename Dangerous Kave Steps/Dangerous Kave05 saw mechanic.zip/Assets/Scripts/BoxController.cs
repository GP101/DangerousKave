﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using KaveUtil;

[RequireComponent(typeof(BoxCollider2D))]
public class BoxController : MonoBehaviour
{
    enum EState
    {
        IDLE,
        PREMOVING,
        MOVING
    }

    public float _speed = 1;
    [Range(0, 360)]
    public float _velocityDegree = 0;

    [SerializeField]
    private BoxCollider2D _boxCollider;
    [SerializeField]
    private Transform _boxArrow;
    private SpriteRenderer _arrowSprite;

    private float _acceleration = 1;
    private Vector2 _curVelocity = new Vector2(0, 0);
    private Vector2 _maxVelocity = new Vector2(1, -1);
    private int _numCollision = 0;
    private bool _isGrounded = false;
    private bool _isInAir = false;

    private EState _movingState = EState.IDLE;
    private float _stateTimer = 0.0f;
    private CircularQueue<Vector2> _posQueue = new CircularQueue<Vector2>(10);
    private float _posQueueInsertTimer = 0.0f; // insert position for every 0.1 second.
    private bool _isContactSaw = false;
    private float _sawContactTimer = 0f;
    [SerializeField]
    private GameObject _grindEffect;
    private GameObject _grindEffectInstance = null;
    private Vector2 _grindContactPos;

    void Start()
    {
        _boxCollider = GetComponent<BoxCollider2D>();
        Debug.Assert(_boxCollider != null);

        _boxArrow = transform.Find("Box Arrow");
        Debug.Assert(_boxArrow);
        _arrowSprite = _boxArrow.gameObject.GetComponent<SpriteRenderer>();
        Debug.Assert(_arrowSprite);

        UpdateMaxVelocity();
    }

    void Update()
    {
        _stateTimer += Time.deltaTime;
        if (_movingState == EState.IDLE)
        {
            _Update_StateIDLE();
            _arrowSprite.color = Color.white;
            
        }
        else if (_movingState == EState.PREMOVING)
        {
            _arrowSprite.color = Color.black;
            if (_stateTimer >= 1.0f)
            {
                _movingState = EState.MOVING;
                _stateTimer = 0.0f;
            }
        }
        else if (_movingState == EState.MOVING)
        {
            _Update_StateMOVING();
            //c.g = Mathf.PingPong(_stateTimer, 0.5f);
            _arrowSprite.color = Color.green;

            if (_isContactSaw)
            {
                _sawContactTimer += Time.deltaTime;
                _arrowSprite.color = Color.red;
                if ( _sawContactTimer >= 1.0f )
                {
                    LevelManager.CreateEffect(LevelManager.EffectType.BigImpact, transform.position, transform.rotation);
                    Destroy(gameObject);
                    Destroy(_grindEffectInstance);
                }
            }
        }
    }

    void OnDrawGizmos()
    {
        // draw velocity
        //
        UpdateMaxVelocity();
        Color oldColor = Gizmos.color;
        Gizmos.color = Color.red;
        Gizmos.DrawRay(transform.position, _maxVelocity);

        // draw state
        //
        string text = string.Format("{0} {1}", _numCollision, _movingState);
        Util.DrawTextInSceneView(transform.position, text, Color.white);
        Gizmos.color = oldColor; // restore original Gizmos color
    }

    void _Update_StateIDLE()
    {
        // Retrieve all colliders we have intersected after velocity has been applied.
        Collider2D[] hits = Physics2D.OverlapBoxAll(transform.position, _boxCollider.size, 0);
        foreach (Collider2D hit in hits)
        {
            // Ignore our own collider.
            if (hit == _boxCollider)
                continue;

            if (hit.gameObject.CompareTag("Player") || hit.gameObject.CompareTag("Box"))
            {
                //_movingState = EState.PREMOVING;
                _movingState = EState.MOVING; // test _20200328_jintaeks
                _stateTimer = 0.0f;
            }

            ColliderDistance2D colliderDistance = hit.Distance(_boxCollider);
            if (colliderDistance.isOverlapped)
            {
            }
        }
    }

    void _StateMOVING_UpdateCollision()
    {
        _curVelocity = Vector2.MoveTowards(_curVelocity, _maxVelocity, _acceleration * Time.deltaTime);
        transform.Translate(_curVelocity * Time.deltaTime);

        _isGrounded = false;
        bool isInAir = true;
        bool isContactSaw = false;

        // Retrieve all colliders we have intersected after velocity has been applied.
        Collider2D[] hits = Physics2D.OverlapBoxAll(transform.position, _boxCollider.size, 0);

        _numCollision = hits.Length;

        foreach (Collider2D hit in hits)
        {
            // Ignore our own collider.
            if (hit == _boxCollider)
                continue;

            if (hit.gameObject.CompareTag("Player") || hit.gameObject.CompareTag("Box") || hit.gameObject.CompareTag("Saw"))
            {
                _stateTimer = 0.0f; // initialize timer when there is a collision with 'Player' or 'Box'
            }

            isInAir = false;
            ColliderDistance2D colliderDistance = hit.Distance(_boxCollider);

            if (colliderDistance.isOverlapped)
            {
                if (hit.gameObject.CompareTag("Saw"))
                {
                    isContactSaw = true;
                    _grindContactPos = colliderDistance.pointB;
                }
                transform.Translate(colliderDistance.pointA - colliderDistance.pointB);

                // If we intersect an object beneath us, set grounded to true. 
                if (Vector2.Angle(colliderDistance.normal, Vector2.up) < 90 && _curVelocity.y < 0)
                {
                    _isGrounded = true;
                }
            }
        }

        if (isInAir != _isInAir)
        {
            _isInAir = isInAir;
        }

        if (_isContactSaw != isContactSaw)
        {
            _isContactSaw = isContactSaw;
            if (_isContactSaw && _grindEffectInstance == null )
                _grindEffectInstance = Instantiate(_grindEffect, _grindContactPos, transform.rotation);
            if (_grindEffectInstance)
                _grindEffectInstance.SetActive(_isContactSaw);
        }
    }

    void _Update_StateMOVING()
    {
        // process collision response
        _StateMOVING_UpdateCollision();

        // check possible next state
        _posQueueInsertTimer += Time.deltaTime;
        if (_posQueueInsertTimer >= 0.1f)
        {
            Vector2 pos = transform.position;
            _posQueue.Insert(pos);
            _posQueueInsertTimer -= 0.1f;
        }
        if (_stateTimer >= 1.0f)
        {
            Vector2 vFront;
            Vector2 vRear;
            bool bFront = _posQueue.GetFront(out vFront);
            bool bRear = _posQueue.GetRear(out vRear);
            if (bFront && bRear)
            {
                float dist = Vector2.Distance(vFront, vRear);
                if (dist <= 0.2f)
                {
                    _movingState = EState.IDLE;
                    _posQueue.ClearAll();
                    _stateTimer = 0.0f;
                }
            }
        }
    }

    void UpdateMaxVelocity()
    {
        _maxVelocity = Util.Rotate(Vector2.right, _velocityDegree * Mathf.Deg2Rad) * _speed;
        Quaternion q = Quaternion.AngleAxis(_velocityDegree, Vector3.forward);
        _boxArrow.transform.SetPositionAndRotation(_boxArrow.transform.position, q);
    }
}//class BoxController
