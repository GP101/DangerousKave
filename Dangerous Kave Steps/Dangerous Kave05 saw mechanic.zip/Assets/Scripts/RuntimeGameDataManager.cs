﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RuntimeGameDataManager : MonoBehaviour
{
    // Now we are using the pseudo singleton.
    // 20200328_jintaeks
    //static private RuntimeGameDataManager instance;
    //static public RuntimeGameDataManager Instance
    //{
    //    get { return instance; }
    //}
    private static int _dataStamp = 0;
    public static int DataStamp
    {
        get { return _dataStamp; }
    }
    private static int _coinCounter = 0;
    //GameObject _player;

    private void Awake()
    {
        // data initialization can be placed here
        // 20200328_jintaeks

        //if (instance == null)
        //    instance = this;
        //_player = GameObject.FindGameObjectWithTag("Player");
        //CharacterController2D cc2d = _player.GetComponent<CharacterController2D>();
        //cc2d.OnCollision += OnCollisionCallback;
    }

    static void UpdateDataStamp()
    {
        ++_dataStamp;
    }

    public static int GetCoinCounter()
    {
        return _coinCounter;
    }

    public static void AddCoinCounter(int c)
    {
        _coinCounter += c;
        UpdateDataStamp();
    }
}//public class RuntimeGameDataManager : MonoBehaviour
