﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinTrigger : MonoBehaviour
{
    private GameObject _player;

    private void Awake()
    {
        _player = GameObject.FindGameObjectWithTag("Player");
        CharacterController2D cc2d = _player.GetComponent<CharacterController2D>();
        cc2d.OnCollision += OnCollisionCallback;
    }

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // will not be called, because collision response is processed in the 'CharacterController2D'
        // 20200328
    }

    void OnCollisionCallback(Collider2D coll2d, ColliderDistance2D collDist2d)
    {
        if (coll2d.gameObject.CompareTag("Coin"))
        {
            Destroy(coll2d.gameObject);
            LevelManager.CreateEffect(LevelManager.EffectType.ItemEffect, transform.position, transform.rotation);
            RuntimeGameDataManager.AddCoinCounter(1);
        }
    }
}
