﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CannonController : BoxBehaviour
{
    public Transform _muzzlePoint;
    public Transform _bullet;
    public float _fireInterval = 2.0f; // unit: second
    private float _fireTimer = 0.0f;

    // Start is called before the first frame update
    override public void OnStart()
    {
        if (_bullet == null)
            _bullet = Resources.Load("Bullet") as Transform;
    }

    // Update is called once per frame
    override public void OnUpdate(EState movingState, float stateTimer)
    {
        // need to delete: jintaeks on 20200428
        //if (Input.GetKeyDown(KeyCode.Alpha1))
        //{
        //    if (_bullet)
        //    {
        //        Transform b = Instantiate(_bullet, _muzzlePoint.position, Quaternion.identity) as Transform;
        //        BulletController bc = b.GetComponent<BulletController>();
        //        bc.velocity = maxVelocity; 
        //    }
        //}
        _fireTimer += Time.deltaTime;
        if (_fireTimer >= _fireInterval)
        {
            _fireTimer = 0.0f;
            _FireBullet();
        }
    }

    override public void OnOverlapped(Collider2D hit, ColliderDistance2D colliderDistance)
    {
        if (hit.transform.CompareTag("Player"))
        {
            hit.transform.Translate(colliderDistance.pointB - colliderDistance.pointA);
        }
        else
        {
            if( base.movingState == EState.MOVING )
                transform.Translate(colliderDistance.pointA - colliderDistance.pointB);
        }
    }

    private void _FireBullet()
    {
        Transform b = Instantiate(_bullet, _muzzlePoint.position, Quaternion.identity) as Transform;
        BulletController bc = b.GetComponent<BulletController>();
        bc.velocity = maxVelocity;
    }
}
