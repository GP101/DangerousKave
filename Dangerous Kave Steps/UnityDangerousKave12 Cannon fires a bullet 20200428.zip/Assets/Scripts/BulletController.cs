﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletController : MonoBehaviour
{
    private Vector2 _velocity;
    public Vector2 velocity
    {
        get { return _velocity; }
        set { _velocity = value; }
    }
    private CircleCollider2D _circleCollider;
    private float _lifeTimer = 0.0f;
    private Camera _mainCamera = null;

    // Start is called before the first frame update
    void Start()
    {
        _circleCollider = GetComponent<CircleCollider2D>();
        _mainCamera = Camera.main;
    }

    // Update is called once per frame
    void Update()
    {
        _lifeTimer += Time.deltaTime;
        Vector3 screenPoint = _mainCamera.WorldToViewportPoint(transform.position);
        bool isInViewport = (screenPoint.z > 0 && screenPoint.x > 0 && screenPoint.x < 1 && screenPoint.y > 0 && screenPoint.y < 1);
        if (isInViewport == false)
        {
            Destroy(gameObject);
        }

        transform.Translate(_velocity * Time.deltaTime);
        Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position
            , _circleCollider.radius*transform.localScale.x);
        foreach (Collider2D hit in hits)
        {
            // Ignore our own collider.
            if (hit.transform == transform)
                continue;
            if (hit.transform.CompareTag("Player"))
            {
                // @TODO: must be moved into CharacterController2D
                // @date: 20200428 
                Destroy(hit.gameObject);
            }
            LevelManager.CreateEffect(LevelManager.EffectType.SmallImpact, transform.position, transform.rotation);
            Destroy(gameObject);
            break;
        }
    }
}