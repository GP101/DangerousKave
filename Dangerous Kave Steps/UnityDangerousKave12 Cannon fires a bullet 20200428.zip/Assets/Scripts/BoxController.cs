﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using KaveUtil;

[RequireComponent(typeof(BoxCollider2D))]
public class BoxController : BoxBehaviour
{
    private bool _isContactSaw = false;
    private float _sawContactTimer = 0f;
    [SerializeField]
    private GameObject _grindEffect = null;
    private GameObject _grindEffectInstance = null;
    private Vector2 _grindContactPos;
    private bool isContactSawTemp = false;

    override public void OnUpdate(EState movingState, float stateTimer)
    {
        //if (movingState == EState.MOVING)
        {
            if (_isContactSaw)
            {
                _sawContactTimer += Time.deltaTime;
                SetArrowSpriteColor(Color.red);
                if (_sawContactTimer >= 1.0f)
                {
                    LevelManager.CreateEffect(LevelManager.EffectType.BigImpact, transform.position, transform.rotation);
                    Destroy(gameObject);
                    Destroy(_grindEffectInstance);
                }
            }
        }
    }

    override public void OnPreCollision()
    {
        if (base.movingState == EState.MOVING )
            isContactSawTemp = false;
    }

    override public void OnOverlapped(Collider2D hit, ColliderDistance2D colliderDistance)
    {
        if (hit.transform.CompareTag("Saw"))
        {
            isContactSawTemp = true;
            _grindContactPos = colliderDistance.pointB;
        }

        if (hit.transform.CompareTag("Player"))
        {
            hit.transform.Translate(colliderDistance.pointB - colliderDistance.pointA);
        }
        else
        {
            transform.Translate(colliderDistance.pointA - colliderDistance.pointB);
        }
    }

    override public void OnPostCollision()
    {
        if (_isContactSaw != isContactSawTemp)
        {
            _isContactSaw = isContactSawTemp;
            if (_isContactSaw && _grindEffectInstance == null)
                _grindEffectInstance = Instantiate(_grindEffect, _grindContactPos, transform.rotation);
            if (_grindEffectInstance)
                _grindEffectInstance.SetActive(_isContactSaw);
        }
    }

    override public bool OnStateIdle_Hit(RaycastHit2D hit)
    {
        base.SetState(EState.MOVING);
        return true;
    }

    override public void OnExternalCollision(GameObject gameObject)
    {
        if (gameObject.CompareTag("Player"))
        {
            if( base.movingState == EState.IDLE )
                base.SetState(EState.MOVING);
        }
    }
}//class BoxController
