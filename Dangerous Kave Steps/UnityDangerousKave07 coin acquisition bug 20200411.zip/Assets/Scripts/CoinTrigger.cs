﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(BoxCollider2D))]
public class CoinTrigger : MonoBehaviour
{
    BoxCollider2D _collider;
    private void Awake()
    {
    }

    // Start is called before the first frame update
    void Start()
    {
        _collider = GetComponent<BoxCollider2D>();
    }

    // Update is called once per frame
    void Update()
    {
        //_collider.Cast()
        RaycastHit2D hit = Physics2D.BoxCast(transform.position, _collider.size, 0, new Vector2(0, 0));
        if (hit.collider)
        {
            if (hit.transform.CompareTag("Player"))
            {
                RuntimeGameDataManager.AddCoinCounter();
                LevelManager.CreateEffect(LevelManager.EffectType.ItemEffect, transform.position, transform.rotation);
                Destroy(transform.gameObject);
            }
        }
    }
}
